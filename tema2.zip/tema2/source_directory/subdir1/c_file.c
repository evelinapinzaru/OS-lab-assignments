#include<stdio.h>
#include<stdlib.h>

int main(void) {
unsigned short int a = 2, b = 4, suma = 0;

suma = a + b;
printf("Suma dintre %hu si %hu este %hu.\n", a, b, suma);

return EXIT_SUCCESS;
}
