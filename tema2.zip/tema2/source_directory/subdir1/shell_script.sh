#!/bin/bash
echo "Care e painea preferata a matematicienilor ?";
sleep 1.5
echo "Painea integrala."
