void parcurge_proceseaza(char*, char*);
